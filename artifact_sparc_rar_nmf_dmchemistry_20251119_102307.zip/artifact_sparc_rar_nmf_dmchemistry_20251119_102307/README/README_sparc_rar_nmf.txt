﻿SPARC RAR + NMF
===================================================

This artifact accompanies the SPARC-based experiment where
non-negative matrix factorization (NMF) is applied to
normalized rotation-curve shapes and the resulting
"mixture fractions" are used to define galaxy subgroups.

Contents
--------

code/
  - sparc_rar_nmf_robust.py
      Main driver: builds the v^2(r/Rmax) matrix, runs NMF for
      multiple (n_components, n_bins, seed, threshold) configs,
      fits a 1-parameter McGaugh-style RAR globally and per group,
      and writes group-level summaries to CSV.

  - sparc_rar_nmf_comp3_meta_plots.py
      Helper: baseline NMF configuration (k=3, 15 bins, seed 123,
      threshold 0.6); constructs per-galaxy diagnostics and plots
      for the comp3_dom subgroup.

data/
  - SPARC_Rotmod/   (if present)
      Original SPARC rotation-curve "rotmod" files used to build
      the v^2(r/Rmax) profiles.

  - SPARC_Table1_full.csv
      SPARC Table 1 metadata (distance, inclination, luminosity,
      HI mass, Vflat, etc.) in CSV form, as used in the joins.

results/sparc_rar_nmf_robust/
  - sparc_rar_nmf_robust_groups.csv
      RAR fit results (g_dag, sigma_int, N_gal, N_pts, residuals)
      for each NMF configuration and group.

  - sparc_rar_nmf_robust_pairs.csv
      Config-level record of which pairs of groups have non-overlapping
      68% intervals in g_dag.

  - sparc_rar_nmf_baseline_mixtures.csv
      Per-galaxy NMF mixture fractions (f1,f2,f3) and dominant component
      for the baseline configuration (k=3, 15 bins, seed 123, thr=0.6).

  - sparc_rar_nmf_baseline_comp3_galaxies_full_diagnostics.csv
      Diagnostics for the four comp3_dom galaxies (per-galaxy RAR,
      N_pts, g_dag, sigma_int, etc.).

  - sparc_rar_nmf_baseline_comp3_with_table1.csv
      Join between comp3_dom diagnostics and SPARC Table 1 metadata
      (T, D, Inc, L[3.6], MHI, Vflat, Q,...).

  - sparc_rar_nmf_baseline_all_with_table1.csv
      Same join for all galaxies, plus NMF mixture fractions.

  - sparc_rar_nmf_baseline_group_metadata_summary.csv
      Group-level averages of key SPARC metadata (distance, inclination,
      3.6 micron luminosity, HI mass, Vflat) per NMF-defined group.

  - sparc_rar_nmf_baseline_groups_paper_ready.csv
      Compact baseline table with group-wise N_gal, N_pts, g_dag,
      sigma_int, and metadata, ready to be imported into LaTeX.

  - sparc_rar_nmf_baseline_groups_table.tex
      LaTeX table for the baseline NMF configuration, used in the paper.

  - sparc_rar_nmf_comp3_nonoverlap_summary.txt
      Text summary: for k=3, across all (n_bins, seed, threshold)
      configurations, ~40% of cases where comp3_dom exists show
      non-overlapping 1σ intervals in g_dag between comp3_dom and
      mixed/comp1_dom/comp2_dom.

  - sparc_rar_nmf_comp3_config_summary.csv
      Per-configuration summary for comp3_dom: N_gal, g_dag, and flags
      for 1σ non-overlap vs mixed, comp1_dom, and comp2_dom.

  - sparc_rar_nmf_comp3_config_table.tex
      Appendix-style LaTeX table listing the configurations in which
      comp3_dom appears and whether its g_dag interval is disjoint.

  - (PNG figures)
      RAR plot color-coded by dominant NMF component, residual histograms,
      and residual boxplots per group.

docs/
  - README_sparc_rar_nmf_dmchemistry.txt  (this file)
  - discovery_paragraph.tex               (paper-ready text snippet)

Scientific summary
------------------

Using the SPARC rotation-curve sample (116 galaxies, 2879 points),
we build normalized v^2(r/Rmax) profiles and perform non-negative
matrix factorization (NMF) with k=3 components. Each galaxy is
represented by mixture fractions (f1,f2,f3) and assigned to a
dominant component when max_j f_j >= 0.6; the rest are labelled
"mixed". For each NMF-defined subgroup we fit a one-parameter
McGaugh-type radial acceleration relation (RAR),

  g_obs = g_bar / [ 1 - exp(-g_bar / g^dagger) ].

The global SPARC sample yields g^dagger ~ 4.4e-11 m s^-2 with
intrinsic scatter ~0.20 dex. The comp1_dom, comp2_dom, and mixed
subgroups recover similar acceleration scales (g^dagger ~(3-5)e-11),
with overlapping 68% confidence intervals. In contrast, the
comp3_dom subgroup (4 galaxies, 116 points) prefers an acceleration
scale of order g^dagger_(3) ~ 1e-13–1e-12 m s^-2, with a 1σ interval
that does not overlap the other groups in the baseline configuration.

A robustness scan over NMF hyper-parameters (N_bins=12,15; seeds
7,42,123; dominance thresholds 0.5,0.6,0.7) shows that whenever a
comp3_dom subgroup exists it consistently selects galaxies with much
lower best-fit g^dagger; in ~40% of those configurations the 68%
intervals in g^dagger for comp3_dom and the comparison group
(mixed, comp1_dom, or comp2_dom) do not intersect. Joins with the
SPARC Table 1 metadata demonstrate that comp3_dom galaxies are not
trivially pathological in distance, inclination, luminosity, or
V_flat, suggesting that the NMF decomposition isolates a genuine
latent sub-population whose effective RAR acceleration scale is
strongly suppressed relative to the bulk of SPARC galaxies.

