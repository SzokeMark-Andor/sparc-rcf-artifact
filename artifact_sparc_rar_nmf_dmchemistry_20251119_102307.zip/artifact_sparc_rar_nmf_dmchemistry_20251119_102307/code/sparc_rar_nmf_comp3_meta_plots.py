﻿import os
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from astropy.io import ascii as ascii

# Constants: km/s, kpc -> m/s^2
KPC_IN_M  = 3.0856775814913673e19
KM2_IN_M2 = 1.0e6
ACC_FACTOR = KM2_IN_M2 / KPC_IN_M   # V[km/s]^2 / R[kpc] * ACC_FACTOR = m/s^2


# -------------------------------------------------------------------
# 1. RAR model and single-galaxy fitting
# -------------------------------------------------------------------

def rar_model(gbar, g_dag):
    """
    McGaugh-style empirical RAR:
      g_obs = g_bar / (1 - exp(-sqrt(g_bar / g_dag)))
    evaluated in linear space.
    """
    gbar = np.asarray(gbar, dtype=float)
    x = np.clip(gbar / g_dag, 1e-12, None)
    s = np.sqrt(x)
    denom = 1.0 - np.exp(-s)
    denom = np.clip(denom, 1e-6, None)
    return gbar / denom


def fit_rar_gdag(gbar, gobs, log_gdag_min=-13.5, log_gdag_max=-9.0, n_grid=250):
    """
    Fit g_dag for a single galaxy by minimizing chi^2 in log10-space,
    and compute intrinsic scatter sigma_int.

    Returns dict with:
      g_dag, g_dag_lo, g_dag_hi, chi2, N, resid_mean, resid_std, sigma_int
    or None if too few points.
    """
    gbar = np.asarray(gbar, dtype=float)
    gobs = np.asarray(gobs, dtype=float)

    m = np.isfinite(gbar) & np.isfinite(gobs) & (gbar > 0) & (gobs > 0)
    if np.count_nonzero(m) < 8:
        return None

    gbar = gbar[m]
    gobs = gobs[m]
    loggbar = np.log10(gbar)
    loggobs = np.log10(gobs)

    log_grid = np.linspace(log_gdag_min, log_gdag_max, n_grid)
    chi2 = np.zeros_like(log_grid)

    for i, lg in enumerate(log_grid):
        g_dag = 10.0**lg
        gmod = rar_model(gbar, g_dag)
        loggmod = np.log10(gmod)
        res = loggobs - loggmod
        chi2[i] = np.sum(res**2)

    idx_best = int(np.argmin(chi2))
    logg_best = float(log_grid[idx_best])
    chi2_best = float(chi2[idx_best])

    mask_1s = chi2 <= chi2_best + 1.0
    if np.any(mask_1s):
        logg_lo = float(log_grid[mask_1s][0])
        logg_hi = float(log_grid[mask_1s][-1])
    else:
        logg_lo = logg_hi = logg_best

    g_dag     = 10.0**logg_best
    g_dag_lo  = 10.0**logg_lo
    g_dag_hi  = 10.0**logg_hi

    # residuals and intrinsic scatter
    gmod_best = rar_model(gbar, g_dag)
    loggmod_best = np.log10(gmod_best)
    res = loggobs - loggmod_best

    resid_mean = float(np.mean(res))
    resid_std  = float(np.std(res, ddof=1))
    sigma_int  = float(np.sqrt(np.mean(res**2)))

    return {
        "g_dag": g_dag,
        "g_dag_lo": g_dag_lo,
        "g_dag_hi": g_dag_hi,
        "chi2": chi2_best,
        "N": int(len(res)),
        "resid_mean": resid_mean,
        "resid_std": resid_std,
        "sigma_int": sigma_int,
    }


# -------------------------------------------------------------------
# 2. Read rotmod files and compute RAR per galaxy
# -------------------------------------------------------------------

def read_rotmod_with_baryons(path):
    """
    Read a SPARC *_rotmod.dat file and return:
      r_kpc, vobs, vgas, vdisk, vbulge  (all in km/s for velocities)
    or None if unusable.
    """
    try:
        df = pd.read_table(path, comment="#", header=None, delim_whitespace=True)
    except Exception as e:
        print(f"  !! Failed to read {path}: {e}")
        return None

    if df.shape[1] < 3:
        return None

    r     = df.iloc[:, 0].to_numpy(dtype=float)
    vobs  = df.iloc[:, 1].to_numpy(dtype=float)
    ncol  = df.shape[1]
    vgas   = df.iloc[:, 3].to_numpy(dtype=float) if ncol > 3 else np.zeros_like(r)
    vdisk  = df.iloc[:, 4].to_numpy(dtype=float) if ncol > 4 else np.zeros_like(r)
    vbulge = df.iloc[:, 5].to_numpy(dtype=float) if ncol > 5 else np.zeros_like(r)

    m = np.isfinite(r) & np.isfinite(vobs) & (r > 0) & (vobs > 0)
    if not m.any():
        return None

    r, vobs, vgas, vdisk, vbulge = r[m], vobs[m], vgas[m], vdisk[m], vbulge[m]
    if r.size < 5:
        return None

    order = np.argsort(r)
    r      = r[order]
    vobs   = vobs[order]
    vgas   = vgas[order]
    vdisk  = vdisk[order]
    vbulge = vbulge[order]

    return r, vobs, vgas, vdisk, vbulge


def compute_rar_for_galaxy(rot_path):
    """
    For a single galaxy rotmod file, compute:
      r_kpc, gbar, gobs, loggbar, loggobs
    """
    rv = read_rotmod_with_baryons(rot_path)
    if rv is None:
        return None
    r, vobs, vgas, vdisk, vbulge = rv

    gobs = (vobs**2) * ACC_FACTOR / r
    vbar2 = vgas**2 + vdisk**2 + vbulge**2
    gbar = vbar2 * ACC_FACTOR / r

    m = np.isfinite(gobs) & np.isfinite(gbar) & (gobs > 0) & (gbar > 0)
    if not m.any():
        return None

    r, gbar, gobs = r[m], gbar[m], gobs[m]
    loggbar = np.log10(gbar)
    loggobs = np.log10(gobs)

    return r, gbar, gobs, loggbar, loggobs, vobs[m], vgas[m], vdisk[m], vbulge[m]


# -------------------------------------------------------------------
# 3. SPARC Table1 master metadata
# -------------------------------------------------------------------

def find_col(df, patterns):
    """
    Find the first column whose name contains any of the substrings in patterns.
    Returns column name or None.
    """
    for pat in patterns:
        lp = pat.lower()
        for col in df.columns:
            if lp in str(col).lower():
                return col
    return None


def download_sparc_table1(out_dir):
    """
    Download SPARC Table1.mrt using astropy.io.ascii and convert to pandas.
    Saves full CSV to out_dir and returns the DataFrame.
    """
    url = "http://astroweb.cwru.edu/SPARC/Table1.mrt"
    print(f"Downloading SPARC Table1 from {url} ...")
    tab = ascii.read(url)
    df = tab.to_pandas()
    csv_full = os.path.join(out_dir, "SPARC_Table1_full.csv")
    df.to_csv(csv_full, index=False)
    print(f"Saved full Table1 to {csv_full}")
    return df


def build_table1_keys(df):
    """
    Add a 'key' column for matching with file names:
      - uppercase
      - remove spaces, hyphens, underscores
    """
    # try to identify the galaxy name column
    candidates = [c for c in df.columns if ("name" in str(c).lower()) or ("gal" in str(c).lower())]
    if not candidates:
        raise RuntimeError(f"Could not find a plausible galaxy name column in Table1. Columns: {df.columns}")
    galcol = candidates[0]
    print(f"Using Table1 column '{galcol}' as galaxy name field.")

    key = (
        df[galcol]
        .astype(str)
        .str.upper()
        .str.replace(" ", "", regex=False)
        .str.replace("-", "", regex=False)
        .str.replace("_", "", regex=False)
    )
    df = df.copy()
    df["key"] = key
    return df, galcol


# -------------------------------------------------------------------
# 4. Per-galaxy plots for baseline comp3_dom
# -------------------------------------------------------------------

def make_comp3_meta_and_plots(sparc_dir, robust_dir):
    """
    Use baseline NMF configuration (n_components=3, n_bins=15, seed=123, T=0.6)
    to:
      - read comp3_dom galaxy list
      - download SPARC Table1 and attach metadata
      - recompute rotation curves + RAR
      - fit per-galaxy RAR g_dag
      - produce per-galaxy rotation curve + RAR plots
      - save combined diagnostics
    """
    # --- Paths from robust run -------------------------------------
    mix_csv   = os.path.join(robust_dir, "sparc_rar_nmf_baseline_mixtures.csv")
    comp3_txt = os.path.join(robust_dir, "sparc_rar_nmf_baseline_comp3_galaxies.txt")
    groups_csv = os.path.join(robust_dir, "sparc_rar_nmf_robust_groups.csv")

    if not os.path.exists(mix_csv):
        raise FileNotFoundError(f"Mixture CSV not found: {mix_csv}")
    if not os.path.exists(comp3_txt):
        raise FileNotFoundError(f"comp3_dom list not found: {comp3_txt}")
    if not os.path.exists(groups_csv):
        raise FileNotFoundError(f"Robust groups CSV not found: {groups_csv}")

    mix = pd.read_csv(mix_csv)
    # list of baseline comp3_dom galaxies
    comp3_list = []
    with open(comp3_txt, "r") as f:
        for line in f:
            line = line.strip()
            if (not line) or line.startswith("#"):
                continue
            comp3_list.append(line)

    if not comp3_list:
        print("No comp3_dom galaxies listed; nothing to do.")
        return

    print("Baseline comp3_dom galaxies:", comp3_list)

    # --- global + group-level g_dag from robust groups -------------
    groups = pd.read_csv(groups_csv)

    # global fit: group == "all", threshold is NaN
    mask_global = (
        (groups["n_components"] == 3) &
        (groups["n_bins"] == 15) &
        (groups["seed"] == 123) &
        (groups["group"] == "all")
    )
    if not mask_global.any():
        raise RuntimeError("Global baseline (3 components, 15 bins, seed=123, group='all') not found.")
    glob_row = groups[mask_global].iloc[0]
    gdag_global = float(glob_row["g_dag"])

    # group fits: threshold=0.6
    mask_groups = (
        (groups["n_components"] == 3) &
        (groups["n_bins"] == 15) &
        (groups["seed"] == 123) &
        (groups["threshold"] == 0.6)
    )
    base_group_rows = groups[mask_groups].copy()
    gdag_by_group = {str(r["group"]): float(r["g_dag"]) for _, r in base_group_rows.iterrows()}
    gdag_comp3 = gdag_by_group.get("comp3_dom", np.nan)
    print("Baseline global g_dag =", gdag_global)
    print("Baseline group g_dag:", gdag_by_group)

    # --- download SPARC Table1 and build match keys ----------------
    table1_df = download_sparc_table1(robust_dir)
    table1_df, name_col = build_table1_keys(table1_df)

    # Identify a few useful metadata columns if present
    type_col = find_col(table1_df, ["type"])
    dist_col = find_col(table1_df, ["dist", "distance"])
    inc_col  = find_col(table1_df, ["inc"])
    mstar_col = find_col(table1_df, ["mstar", "logm", "logmstar"])

    print("Metadata columns guess:")
    print("  name_col =", name_col)
    print("  type_col =", type_col)
    print("  dist_col =", dist_col)
    print("  inc_col  =", inc_col)
    print("  mstar_col=", mstar_col)

    # --- build list of comp3 galaxies with keys --------------------
    rows_diag = []
    plots_dir = os.path.join(robust_dir, "comp3_inspect_plots")
    os.makedirs(plots_dir, exist_ok=True)

    for gid in comp3_list:
        base_id = gid
        for suf in ["_rotmod", "_rotmond", ".dat"]:
            if base_id.endswith(suf):
                base_id = base_id.replace(suf, "")
        key = (
            base_id.upper()
            .replace(" ", "")
            .replace("-", "")
            .replace("_", "")
        )

        # match to metadata
        meta_match = table1_df[table1_df["key"] == key]
        if meta_match.empty:
            meta_found = False
            meta_row = None
        else:
            meta_found = True
            meta_row = meta_match.iloc[0]

        # mixture fractions for this galaxy (if present)
        mix_row = mix[mix["galaxy_id"] == gid]
        f1 = f2 = f3 = np.nan
        dom_comp = np.nan
        dom_frac = np.nan
        if not mix_row.empty:
            row0 = mix_row.iloc[0]
            f1 = float(row0.get("f1", np.nan))
            f2 = float(row0.get("f2", np.nan))
            f3 = float(row0.get("f3", np.nan))
            dom_comp = float(row0.get("dominant_comp", np.nan))
            dom_frac = float(row0.get("dominant_frac", np.nan))

        # locate rotmod file
        candidates = [
            os.path.join(sparc_dir, gid + ".dat"),
            os.path.join(sparc_dir, gid),
            os.path.join(sparc_dir, base_id + "_rotmod.dat"),
            os.path.join(sparc_dir, base_id + ".dat"),
        ]
        rot_path = None
        for c in candidates:
            if os.path.exists(c):
                rot_path = c
                break
        if rot_path is None:
            print(f"  !! Cannot find rotmod file for {gid} (base_id={base_id})")
            continue

        print(f"\nProcessing {gid}  (key={key})")
        rar = compute_rar_for_galaxy(rot_path)
        if rar is None:
            print(f"  !! Could not compute RAR for {gid}")
            continue
        r, gbar, gobs, loggbar, loggobs, vobs, vgas, vdisk, vbulge = rar

        # per-galaxy RAR fit
        fit_gal = fit_rar_gdag(gbar, gobs)
        if fit_gal is None:
            print(f"  !! RAR fit failed for {gid}")
            continue

        # store diagnostics row
        diag = {
            "galaxy_id": gid,
            "base_id": base_id,
            "meta_found": meta_found,
            "N_pts": int(fit_gal["N"]),
            "gdag_gal": fit_gal["g_dag"],
            "gdag_gal_lo": fit_gal["g_dag_lo"],
            "gdag_gal_hi": fit_gal["g_dag_hi"],
            "sigma_int_gal": fit_gal["sigma_int"],
            "f1": f1,
            "f2": f2,
            "f3": f3,
            "dominant_comp": dom_comp,
            "dominant_frac": dom_frac,
        }

        # attach a few metadata fields if present
        if meta_found:
            diag["Table1_name"] = meta_row.get(name_col, "")
            if type_col is not None:
                diag["Type"] = meta_row.get(type_col, "")
            if dist_col is not None:
                diag["Dist"] = meta_row.get(dist_col, np.nan)
            if inc_col is not None:
                diag["Inc"] = meta_row.get(inc_col, np.nan)
            if mstar_col is not None:
                diag["Mstar_like"] = meta_row.get(mstar_col, np.nan)
        else:
            diag["Table1_name"] = ""
            diag["Type"] = ""
            diag["Dist"] = np.nan
            diag["Inc"] = np.nan
            diag["Mstar_like"] = np.nan

        rows_diag.append(diag)

        # --- build per-galaxy plot --------------------------------
        fig, axes = plt.subplots(1, 2, figsize=(10, 4))
        ax_rc, ax_rar = axes

        # rotation curve panel
        ax_rc.plot(r, vobs, "ko", ms=4, label="V_obs")
        ax_rc.plot(r, vgas, "b--", lw=1, label="V_gas")
        ax_rc.plot(r, vdisk, "r--", lw=1, label="V_disk")
        if np.any(vbulge != 0):
            ax_rc.plot(r, vbulge, "g--", lw=1, label="V_bulge")
        ax_rc.set_xlabel("R [kpc]")
        ax_rc.set_ylabel("V [km/s]")
        ax_rc.set_title(gid)
        ax_rc.legend(fontsize=8, loc="best")

        # RAR panel: data
        ax_rar.scatter(loggbar, loggobs, s=15, alpha=0.7, label="data")

        # global RAR curve
        gbar_grid = np.logspace(loggbar.min() - 0.3, loggbar.max() + 0.3, 300)
        gobs_global = rar_model(gbar_grid, gdag_global)
        ax_rar.plot(
            np.log10(gbar_grid),
            np.log10(gobs_global),
            "k-",
            lw=2,
            label=r"global $g_{\dagger}$"
        )

        # comp3_dom group RAR curve (if defined)
        if np.isfinite(gdag_comp3) and gdag_comp3 > 0:
            gobs_c3 = rar_model(gbar_grid, gdag_comp3)
            ax_rar.plot(
                np.log10(gbar_grid),
                np.log10(gobs_c3),
                "m--",
                lw=1.5,
                label=r"comp3\_dom $g_{\dagger}$"
            )

        # per-galaxy best fit
        gobs_gal = rar_model(gbar_grid, fit_gal["g_dag"])
        ax_rar.plot(
            np.log10(gbar_grid),
            np.log10(gobs_gal),
            "c-.",
            lw=1.5,
            label=r"this galaxy $g_{\dagger}$"
        )

        ax_rar.set_xlabel(r"$\log_{10} g_{\mathrm{bar}}\ [{\rm m\,s^{-2}}]$")
        ax_rar.set_ylabel(r"$\log_{10} g_{\mathrm{obs}}\ [{\rm m\,s^{-2}}]$")
        ax_rar.legend(fontsize=8, loc="best")

        # annotate scatter + NMF fractions
        txt_lines = [
            rf"$N$ = {fit_gal['N']}",
            rf"$\sigma_{{\rm int}}$ = {fit_gal['sigma_int']:.3f} dex",
            rf"$g_{{\dagger,\,gal}}$ = {fit_gal['g_dag']:.2e}",
            rf"$f_1,f_2,f_3$ = ({f1:.2f},{f2:.2f},{f3:.2f})",
        ]
        if meta_found:
            if type_col is not None:
                txt_lines.append(f"Type: {meta_row.get(type_col, '')}")
            if dist_col is not None:
                txt_lines.append(f"Dist: {meta_row.get(dist_col, np.nan)}")
            if inc_col is not None:
                txt_lines.append(f"Inc: {meta_row.get(inc_col, np.nan)}")

        ax_rar.text(
            0.03,
            0.97,
            "\n".join(txt_lines),
            transform=ax_rar.transAxes,
            va="top",
            ha="left",
            fontsize=7,
            bbox=dict(boxstyle="round", facecolor="white", alpha=0.7)
        )

        fig.tight_layout()
        out_png = os.path.join(plots_dir, f"sparc_comp3_{gid}.png")
        fig.savefig(out_png, dpi=200)
        plt.close(fig)
        print(f"  Saved per-galaxy plot to {out_png}")

    # --- save diagnostics table ------------------------------------
    if rows_diag:
        diag_df = pd.DataFrame(rows_diag)
        out_csv = os.path.join(robust_dir, "sparc_rar_nmf_baseline_comp3_galaxies_full_diagnostics.csv")
        diag_df.to_csv(out_csv, index=False)
        print("\nWrote comp3_dom diagnostics to", out_csv)
        print(diag_df.to_string(index=False))
    else:
        print("No diagnostics rows written (no successful galaxies?).")


# -------------------------------------------------------------------
# 5. CLI
# -------------------------------------------------------------------

def main():
    if len(sys.argv) != 3:
        print("Usage: sparc_rar_nmf_comp3_meta_plots.py SPARC_DIR ROBUST_RESULTS_DIR")
        sys.exit(1)
    sparc_dir = sys.argv[1]
    robust_dir = sys.argv[2]

    if not os.path.isdir(sparc_dir):
        raise NotADirectoryError(f"SPARC directory not found: {sparc_dir}")
    if not os.path.isdir(robust_dir):
        raise NotADirectoryError(f"Robust results directory not found: {robust_dir}")

    make_comp3_meta_and_plots(sparc_dir, robust_dir)


# --- Patched download_sparc_table1: HTTPS SPARC_Lelli2016c.mrt + local fallback ---
def download_sparc_table1(out_dir):
    """
    Obtain SPARC Table1 / SPARC_Lelli2016c metadata.

    Priority:
      1) If a local CSV or .mrt file is present in out_dir, use that.
      2) Otherwise, try a small list of HTTPS/HTTP URLs,
         preferring SPARC_Lelli2016c.mrt.
    """
    # 1) Local files first
    candidates = [
        "SPARC_Table1_full.csv",   # already converted to CSV
        "SPARC_Lelli2016c.mrt",    # official SPARC galaxy-sample file
        "Table1.mrt",              # older name used in docs
    ]
    for fname in candidates:
        path = os.path.join(out_dir, fname)
        if os.path.exists(path):
            if fname.lower().endswith(".csv"):
                print(f"Found existing SPARC Table1 CSV at {path}, loading...")
                return pd.read_csv(path)
            else:
                print(f"Found local {fname} at {path}, reading with astropy...")
                tab = ascii.read(path)
                df = tab.to_pandas()
                csv_full = os.path.join(out_dir, "SPARC_Table1_full.csv")
                df.to_csv(csv_full, index=False)
                print(f"Saved full Table1 to {csv_full}")
                return df

    # 2) Try URLs (prefer HTTPS, new filename)
    urls = [
        "https://astroweb.cwru.edu/SPARC/SPARC_Lelli2016c.mrt",
        "https://astroweb.cwru.edu/SPARC/Table1.mrt",
        "http://astroweb.cwru.edu/SPARC/SPARC_Lelli2016c.mrt",
        "http://astroweb.cwru.edu/SPARC/Table1.mrt",
    ]

    last_err = None
    for url in urls:
        try:
            print(f"Trying SPARC Table1 from {url} ...")
            tab = ascii.read(url)
            df = tab.to_pandas()
            csv_full = os.path.join(out_dir, "SPARC_Table1_full.csv")
            df.to_csv(csv_full, index=False)
            print(f"Saved full Table1 to {csv_full}")
            return df
        except Exception as e:
            print(f"  !! Failed from {url}: {e}")
            last_err = e

    # If we reach here, everything failed → clean message for offline/firewall case
    raise RuntimeError(
        "Could not obtain SPARC Table1 / SPARC_Lelli2016c.mrt. "
        "Please download SPARC_Lelli2016c.mrt manually from "
        "https://astroweb.cwru.edu/SPARC/SPARC_Lelli2016c.mrt "
        f"into {out_dir} and rerun."
    ) from last_err


if __name__ == "__main__":
    main()

