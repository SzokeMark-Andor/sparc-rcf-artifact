﻿import os, numpy as np, pandas as pd, sys

KPC_IN_M  = 3.0856775814913673e19

def read_rotmod_basic(path):
    import pandas as pd
    df = pd.read_table(path, comment="#", header=None, sep=r"\s+")
    if df.shape[1] < 3:
        return None
    r   = df.iloc[:,0].to_numpy(dtype=float)
    vobs = df.iloc[:,1].to_numpy(dtype=float)
    vgas = df.iloc[:,3].to_numpy(dtype=float) if df.shape[1] > 3 else np.zeros_like(r)
    vdisk = df.iloc[:,4].to_numpy(dtype=float) if df.shape[1] > 4 else np.zeros_like(r)
    vbulge = df.iloc[:,5].to_numpy(dtype=float) if df.shape[1] > 5 else np.zeros_like(r)
    m = np.isfinite(r) & np.isfinite(vobs) & (r>0) & (vobs>0)
    if not m.any():
        return None
    r, vobs, vgas, vdisk, vbulge = r[m], vobs[m], vgas[m], vdisk[m], vbulge[m]
    Rmax = float(r.max())
    Vmax = float(vobs.max())
    vbar2 = vgas**2 + vdisk**2 + vbulge**2
    gas_frac = np.mean(vgas**2 / np.where(vbar2>0, vbar2, np.inf))
    return Rmax, Vmax, gas_frac

def main():
    if len(sys.argv) != 4:
        print("Usage: sparc_rar_nmf_inspect_comp3.py MIX_CSV COMP3_LIST SPARC_DIR")
        sys.exit(1)
    mix_csv, comp3_txt, sparc_dir = sys.argv[1:]
    mix = pd.read_csv(mix_csv)
    comp3_list = []
    with open(comp3_txt,"r") as f:
        for line in f:
            line=line.strip()
            if not line or line.startswith("#"): continue
            comp3_list.append(line)
    mix = mix[mix["galaxy_id"].isin(comp3_list)].copy()
    rows = []
    for gid in comp3_list:
        rotfile = os.path.join(sparc_dir, gid + ".dat")
        if not os.path.exists(rotfile):
            rotfile = os.path.join(sparc_dir, gid)
        info = read_rotmod_basic(rotfile)
        if info is None:
            Rmax = Vmax = gas_frac = np.nan
        else:
            Rmax, Vmax, gas_frac = info
        row = {"galaxy_id": gid, "Rmax_kpc": Rmax, "Vmax_kms": Vmax,
               "gas_frac_v2": gas_frac}
        sub = mix[mix["galaxy_id"]==gid]
        for col in ["f1","f2","f3","dominant_comp","dominant_frac"]:
            if col in sub.columns:
                row[col] = sub.iloc[0][col]
        rows.append(row)
    df = pd.DataFrame(rows)
    out = os.path.join(os.path.dirname(mix_csv),
                       "sparc_rar_nmf_baseline_comp3_galaxies_diagnostics.csv")
    df.to_csv(out, index=False)
    print("Wrote diagnostics to", out)
    print(df.to_string(index=False))

if __name__ == "__main__":
    main()
