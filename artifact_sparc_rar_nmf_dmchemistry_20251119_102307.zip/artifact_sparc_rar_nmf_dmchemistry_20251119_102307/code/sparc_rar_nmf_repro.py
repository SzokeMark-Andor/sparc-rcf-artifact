﻿import os, sys, json
import numpy as np
import pandas as pd
from sklearn.decomposition import NMF
import matplotlib.pyplot as plt
from scipy.optimize import minimize_scalar

# ------------------ I/O: read one SPARC rotmod file ------------------ #

def read_rotmod(path):
    """
    Read one SPARC 'XXXX_rotmod.dat' file.

    We assume (standard SPARC format):
      col 0: radius [kpc]
      col 1: V_obs
      col 2: err(V_obs)
      col 3: V_gas
      col 4: V_disk
      col 5: V_bulge (may be absent for bulgeless disks)
    """
    try:
        # sep='\\s+' with engine='python' avoids the FutureWarning
        df = pd.read_table(path, comment="#", header=None,
                           sep=r"\s+", engine="python")
    except Exception as e:
        print(f"Failed to read {path}: {e}")
        return None

    if df.shape[1] < 5:  # need at least gas+disk
        return None

    r_kpc = df.iloc[:, 0].to_numpy(dtype=float)
    vobs  = df.iloc[:, 1].to_numpy(dtype=float)
    evobs = df.iloc[:, 2].to_numpy(dtype=float)
    vgas  = df.iloc[:, 3].to_numpy(dtype=float)
    vdisk = df.iloc[:, 4].to_numpy(dtype=float)
    if df.shape[1] > 5:
        vbulge = df.iloc[:, 5].to_numpy(dtype=float)
    else:
        vbulge = np.zeros_like(r_kpc)

    mask = (
        np.isfinite(r_kpc) & np.isfinite(vobs) & np.isfinite(evobs) &
        np.isfinite(vgas)  & np.isfinite(vdisk) & np.isfinite(vbulge) &
        (r_kpc > 0) & (vobs > 0)
    )
    if mask.sum() < 10:
        return None

    r_kpc, vobs, evobs, vgas, vdisk, vbulge = [
        arr[mask] for arr in (r_kpc, vobs, evobs, vgas, vdisk, vbulge)
    ]

    order = np.argsort(r_kpc)
    r_kpc, vobs, evobs, vgas, vdisk, vbulge = [
        arr[order] for arr in (r_kpc, vobs, evobs, vgas, vdisk, vbulge)
    ]
    return r_kpc, vobs, evobs, vgas, vdisk, vbulge


# --------- Build NMF matrix + RAR dataset from all galaxies ---------- #

def build_nmf_and_rar_inputs(sparc_dir, n_bins=15):
    rows      = []
    names     = []
    rar_parts = []

    files = sorted(
        f for f in os.listdir(sparc_dir)
        if f.lower().endswith("_rotmod.dat") or f.lower().endswith("_rotmond.dat")
    )
    if not files:
        raise RuntimeError("No *_rotmod.dat files found in " + sparc_dir)

    for fname in files:
        full = os.path.join(sparc_dir, fname)
        data = read_rotmod(full)
        if data is None:
            continue
        r_kpc, vobs, evobs, vgas, vdisk, vbulge = data
        galaxy_id = os.path.splitext(fname)[0]

        # ----- NMF: v^2(r/Rmax) normalised shape -----
        Rmax = float(np.max(r_kpc))
        if not np.isfinite(Rmax) or Rmax <= 0:
            continue

        grid_frac = np.linspace(0.1, 1.0, n_bins)
        r_samp = grid_frac * Rmax

        if np.min(r_kpc) > r_samp[0]:
            # we don't probe inner radii enough
            continue

        v_samp = np.interp(r_samp, r_kpc, vobs, left=np.nan, right=np.nan)
        if np.any(~np.isfinite(v_samp)):
            continue

        v2 = v_samp**2.0
        vmax = np.max(v2)
        if vmax <= 0 or not np.isfinite(vmax):
            continue

        v2_norm = v2 / vmax
        rows.append(v2_norm)
        names.append(galaxy_id)

        # ----- RAR: g_obs, g_bar at native radii -----
        r_m   = r_kpc * 3.085677581e19    # kpc → m
        vobs_mps   = vobs * 1.0e3
        vgas_mps   = vgas * 1.0e3
        vdisk_mps  = vdisk * 1.0e3
        vbulge_mps = vbulge * 1.0e3

        g_obs = vobs_mps**2 / r_m
        g_bar = (vgas_mps**2 + vdisk_mps**2 + vbulge_mps**2) / r_m

        m = np.isfinite(g_obs) & np.isfinite(g_bar) & (g_obs > 0) & (g_bar > 0)
        if m.sum() == 0:
            continue

        part = pd.DataFrame({
            "galaxy_id": galaxy_id,
            "r_kpc": r_kpc[m],
            "g_obs": g_obs[m],
            "g_bar": g_bar[m],
        })
        rar_parts.append(part)

    if not rows:
        raise RuntimeError("No usable galaxies found in " + sparc_dir)

    X = np.vstack(rows)
    names = np.array(names)
    rar_df = pd.concat(rar_parts, ignore_index=True)

    rar_df["log10_g_obs"] = np.log10(rar_df["g_obs"].values)
    rar_df["log10_g_bar"] = np.log10(rar_df["g_bar"].values)

    return X, names, rar_df, grid_frac


# ------------------------- NMF: DM “chemistry” ------------------------ #

def run_nmf(X, names, n_components=3, f_dom_thresh=0.6):
    model = NMF(
        n_components=n_components,
        init="nndsvda",
        max_iter=5000,
        random_state=123
    )
    W = model.fit_transform(X)         # N_gal × n_components
    H = model.components_             # n_components × n_bins

    W_sum = np.sum(W, axis=1, keepdims=True)
    W_sum[W_sum == 0.0] = 1.0
    F = W / W_sum  # fractions per galaxy

    mix_cols = [f"f{j+1}" for j in range(n_components)]
    mixture = pd.DataFrame(F, columns=mix_cols)
    mixture.insert(0, "galaxy_id", names)

    max_f = F.max(axis=1)
    argmax = F.argmax(axis=1) + 1  # 1..n_components
    dom = np.where(max_f >= f_dom_thresh, argmax, 0)  # 0 = mixed
    mixture["dominant_comp"] = dom

    return mixture, H


# ---------------------- RAR model + g_dag fitting --------------------- #

def rar_model(g_bar, g_dag):
    """McGaugh+2016-type interpolation function."""
    x = g_bar / g_dag
    return g_bar / (1.0 - np.exp(-np.sqrt(x)))


def fit_g_dag_for_subset(df, log10_range=(-13.5, -9.0), label="all"):
    g_bar = df["g_bar"].to_numpy()
    g_obs = df["g_obs"].to_numpy()

    if g_bar.size < 20:
        return {
            "group": label,
            "N_pts": int(g_bar.size),
            "N_gal": int(df["galaxy_id"].nunique()),
            "g_dag": np.nan,
            "g_dag_lo": np.nan,
            "g_dag_hi": np.nan,
            "chi2": np.nan,
            "resid_mean": np.nan,
            "resid_std": np.nan,
        }

    log10_gbar = np.log10(g_bar)
    log10_gobs = np.log10(g_obs)

    def chi2_from_log10(log10_gdag):
        gdag = 10.0**log10_gdag
        gmod = rar_model(g_bar, gdag)
        if np.any(~np.isfinite(gmod)) or np.any(gmod <= 0):
            return np.inf
        lg = np.log10(gmod)
        resid = log10_gobs - lg
        return np.sum(resid**2)

    grid = np.linspace(log10_range[0], log10_range[1], 91)
    vals = np.array([chi2_from_log10(x) for x in grid])
    best_idx = int(np.argmin(vals))
    best_log10 = grid[best_idx]
    chi2_best = float(vals[best_idx])

    # crude 1σ region where Δχ² <= 1
    mask = vals <= chi2_best + 1.0
    lo_log10 = grid[mask].min()
    hi_log10 = grid[mask].max()

    gdag = 10.0**best_log10
    gdag_lo = 10.0**lo_log10
    gdag_hi = 10.0**hi_log10

    gmod_best = rar_model(g_bar, gdag)
    log10_gmod = np.log10(gmod_best)
    resid = log10_gobs - log10_gmod

    return {
        "group": label,
        "N_pts": int(g_bar.size),
        "N_gal": int(df["galaxy_id"].nunique()),
        "g_dag": float(gdag),
        "g_dag_lo": float(gdag_lo),
        "g_dag_hi": float(gdag_hi),
        "chi2": chi2_best,
        "resid_mean": float(resid.mean()),
        "resid_std": float(resid.std(ddof=1)),
    }


# -------------- Attach mixture info to RAR point-by-point ------------- #

def attach_mixture_to_rar(rar_df, mixture):
    rar = rar_df.merge(mixture, on="galaxy_id", how="left")
    # map dominant_comp → string group label
    mapping = {1: "comp1_dom", 2: "comp2_dom", 3: "comp3_dom"}
    rar["group"] = rar["dominant_comp"].map(mapping).fillna("mixed")
    return rar


# ------------------------ Discovery heuristic ------------------------- #

def check_discovery(groups):
    """
    Very simple: if any pair of groups has non-overlapping 1σ intervals in g_dag
    and both have N_gal >= 3, we flag as 'discovery candidate'.
    """
    useful = [
        g for g in groups
        if np.isfinite(g["g_dag"]) and g["N_gal"] >= 3
    ]
    pairs = []
    for i in range(len(useful)):
        for j in range(i+1, len(useful)):
            a, b = useful[i], useful[j]
            if a["g_dag_hi"] < b["g_dag_lo"] or b["g_dag_hi"] < a["g_dag_lo"]:
                pairs.append((a["group"], b["group"]))
    return pairs


# -------------------------- Plotting helper --------------------------- #

def make_rar_plot(rar_df, g_dag_global, out_png):
    fig, ax = plt.subplots()

    # all points in grey
    ax.scatter(
        rar_df["log10_g_bar"], rar_df["log10_g_obs"],
        s=5, alpha=0.2, color="0.8"
    )

    colors = {
        "comp1_dom": "tab:blue",
        "comp2_dom": "tab:orange",
        "comp3_dom": "tab:green",
    }
    for group, color in colors.items():
        m = rar_df["group"] == group
        if not m.any():
            continue
        ax.scatter(
            rar_df.loc[m, "log10_g_bar"],
            rar_df.loc[m, "log10_g_obs"],
            s=10, alpha=0.9, label=group, color=color
        )

    # global RAR fit line
    gbar_min = rar_df["g_bar"].min()
    gbar_max = rar_df["g_bar"].max()
    gbar_grid = np.logspace(np.log10(gbar_min), np.log10(gbar_max), 200)
    gobs_grid = rar_model(gbar_grid, g_dag_global)
    ax.plot(
        np.log10(gbar_grid),
        np.log10(gobs_grid),
        "k-", linewidth=2, label="global RAR fit"
    )

    ax.set_xlabel(r"$\log_{10} g_{\rm bar}\ [{\rm m\,s^{-2}}]$")
    ax.set_ylabel(r"$\log_{10} g_{\rm obs}\ [{\rm m\,s^{-2}}]$")
    ax.legend()
    fig.tight_layout()
    fig.savefig(out_png, dpi=200)
    plt.close(fig)


# --------------------- Main driver (reproducible) --------------------- #

def run_sparc_rar_nmf_repro(sparc_dir, out_dir,
                             n_components=3, n_bins=15,
                             f_dom_thresh=0.6):
    os.makedirs(out_dir, exist_ok=True)

    print(f"Building NMF and RAR inputs from {sparc_dir} ...")
    X, names, rar_df, grid_frac = build_nmf_and_rar_inputs(
        sparc_dir, n_bins=n_bins
    )
    print(f" -> N_galaxies used in NMF: {X.shape[0]}, "
          f"N_points_per_curve: {X.shape[1]}")
    print(f" -> Total RAR points: {rar_df.shape[0]}")

    mixture, H = run_nmf(X, names, n_components=n_components,
                         f_dom_thresh=f_dom_thresh)
    rar = attach_mixture_to_rar(rar_df, mixture)

    # ----- summaries -----
    print("\n=== NMF mixture fractions per galaxy (first few) ===")
    print(mixture.head(20).to_string(index=False))

    print("\n=== Mixture statistics ===")
    for j in range(n_components):
        col = f"f{j+1}"
        comp = mixture[col].to_numpy()
        print(f"Component {j+1}: mean={comp.mean():.3f}, "
              f"std={comp.std():.3f}, min={comp.min():.3f}, "
              f"max={comp.max():.3f}, N(f>0.8)={(comp>0.8).sum()}")

    # global fit
    global_stats = fit_g_dag_for_subset(rar, label="all")
    print("\n=== Global RAR fit (all galaxies) ===")
    print("g_dag(all) = {0:.3e} [{1:.3e}, {2:.3e}]  "
          "(N={3}, chi2={4:.2f})".format(
              global_stats["g_dag"],
              global_stats["g_dag_lo"],
              global_stats["g_dag_hi"],
              global_stats["N_pts"],
              global_stats["chi2"],
          ))
    print("Residuals (all): mean={0:.3f} dex, std={1:.3f} dex".format(
        global_stats["resid_mean"], global_stats["resid_std"]
    ))

    # per-group fits
    groups = []
    print("\n=== RAR by NMF-based groups ===")
    for label in ["comp1_dom", "comp2_dom", "comp3_dom", "mixed"]:
        sub = rar[rar["group"] == label]
        stats = fit_g_dag_for_subset(sub, label=label)
        groups.append(stats)
        print("{0}: N_gal={1}, N_pts={2}, g_dag={3:.3e} "
              "[{4:.3e}, {5:.3e}], resid mean={6:.3f} dex, "
              "std={7:.3f} dex".format(
                  label,
                  stats["N_gal"], stats["N_pts"],
                  stats["g_dag"], stats["g_dag_lo"],
                  stats["g_dag_hi"],
                  stats["resid_mean"], stats["resid_std"]
              ))

    # discovery candidate?
    different_pairs = check_discovery(groups)
    if different_pairs:
        print("\n*** RAR + NMF DISCOVERY CANDIDATE ***")
        for a, b in different_pairs:
            print(f"Groups with non-overlapping 1σ g_dag: {a} vs {b}")
    else:
        print("\n*** No strong g_dag separation between groups at 1σ "
              "by this simple test. ***")

    # ----- SAVE EVERYTHING FOR REPRODUCIBILITY -----
    print("\nSaving CSV tables and plot to", out_dir)

    mixture.to_csv(
        os.path.join(out_dir, "sparc_rar_nmf_mixtures.csv"),
        index=False
    )
    rar.to_csv(
        os.path.join(out_dir, "sparc_rar_nmf_rar_points.csv"),
        index=False
    )
    pd.DataFrame(groups).to_csv(
        os.path.join(out_dir, "sparc_rar_nmf_group_summary.csv"),
        index=False
    )
    pd.DataFrame([global_stats]).to_csv(
        os.path.join(out_dir, "sparc_rar_nmf_global_summary.csv"),
        index=False
    )

    config = {
        "n_components": n_components,
        "n_bins": n_bins,
        "f_dom_thresh": f_dom_thresh,
        "rar_model": "McGaugh2016",
        "log10_g_dag_range": [-13.5, -9.0],
        "notes": (
            "SPARC Rotmod_LTG, NMF on v^2(r/Rmax), "
            "RAR fit per NMF dominant component."
        )
    }
    with open(os.path.join(out_dir, "sparc_rar_nmf_config.json"),
              "w", encoding="utf8") as f:
        json.dump(config, f, indent=2)

    # summary text (human-readable)
    summary_path = os.path.join(out_dir, "sparc_rar_nmf_summary.txt")
    with open(summary_path, "w", encoding="utf8") as f:
        f.write("=== Global RAR ===\n")
        f.write(
            "g_dag(all) = {0:.3e} [{1:.3e}, {2:.3e}] "
            "(N={3}, chi2={4:.2f})\n".format(
                global_stats["g_dag"],
                global_stats["g_dag_lo"],
                global_stats["g_dag_hi"],
                global_stats["N_pts"],
                global_stats["chi2"],
            )
        )
        f.write(
            "Residuals (all): mean={0:.3f} dex, "
            "std={1:.3f} dex\n\n".format(
                global_stats["resid_mean"],
                global_stats["resid_std"]
            )
        )
        f.write("=== Group summaries ===\n")
        for g in groups:
            f.write(
                "{group}: N_gal={N_gal}, N_pts={N_pts}, "
                "g_dag={g_dag:.3e} [{g_dag_lo:.3e}, {g_dag_hi:.3e}], "
                "resid_mean={resid_mean:.3f} dex, "
                "resid_std={resid_std:.3f} dex\n".format(**g)
            )
        if different_pairs:
            f.write("\nDiscovery-candidate pairs (non-overlapping 1σ):\n")
            for a, b in different_pairs:
                f.write(f"  {a} vs {b}\n")
        else:
            f.write("\nNo discovery-candidate pairs at 1σ by "
                    "this simple criterion.\n")

    # plot
    out_png = os.path.join(out_dir, "sparc_rar_nmf_discovery.png")
    make_rar_plot(rar, global_stats["g_dag"], out_png)
    print(" -> Saved plot:", out_png)
    print(" -> Saved summary:", summary_path)
    print("\nDone.")


def main():
    if len(sys.argv) != 3:
        print("Usage: sparc_rar_nmf_repro.py SPARC_DIR OUTPUT_DIR")
        sys.exit(1)
    sparc_dir = sys.argv[1]
    out_dir   = sys.argv[2]
    run_sparc_rar_nmf_repro(sparc_dir, out_dir)


if __name__ == "__main__":
    main()
