﻿import os, sys
import numpy as np
import pandas as pd
from sklearn.decomposition import NMF
from scipy.optimize import minimize_scalar
import matplotlib.pyplot as plt

KPC_TO_M = 3.085677581491367e19

def read_one_rotmod(path):
    """
    Read one SPARC Rotmod_LTG file.

    Assumes columns:
      0: R [kpc]
      1: Vobs [km/s]
      2: e_Vobs [km/s]
      3+: baryonic velocity components [km/s] (gas, disk, bulge, ...)
    Returns (r, vobs, e_vobs, vbar) or None if unusable.
    """
    try:
        # KEY FIX: use delim_whitespace instead of sep=r"\\s+"
        df = pd.read_table(path, comment="#", header=None, delim_whitespace=True)
    except Exception as e:
        print(f"Failed to read {path}: {e}")
        return None

    # Need at least R, Vobs, eV, and one baryonic component
    if df.shape[1] < 4:
        return None

    r    = df.iloc[:, 0].to_numpy(dtype=float)   # kpc
    vobs = df.iloc[:, 1].to_numpy(dtype=float)   # km/s
    e_v  = df.iloc[:, 2].to_numpy(dtype=float)   # km/s

    # Combine all baryonic velocity components in quadrature
    bary_cols = df.columns[3:]
    bary = df[bary_cols].to_numpy(dtype=float)   # km/s
    vbar = np.sqrt(np.sum(bary**2.0, axis=1))    # km/s

    m = (
        np.isfinite(r) & np.isfinite(vobs) & np.isfinite(e_v) &
        np.isfinite(vbar) & (r > 0.0) & (vobs > 0.0) & (e_v > 0.0)
    )
    if not np.any(m):
        return None

    r, vobs, e_v, vbar = r[m], vobs[m], e_v[m], vbar[m]

    if r.size < 10:
        return None

    order = np.argsort(r)
    r, vobs, e_v, vbar = r[order], vobs[order], e_v[order], vbar[order]
    return r, vobs, e_v, vbar


def build_nmf_and_rar_inputs(sparc_dir, n_bins=15):
    """
    Build:
      - NMF matrix X: N_gal x n_bins, normalized Vobs^2(r/Rmax)
      - galaxy names
      - global RAR arrays g_bar_all, g_obs_all
      - gal_index_all: which galaxy each RAR point belongs to
      - grid_frac: the common radius grid in units of Rmax
    """
    files = sorted(
        f for f in os.listdir(sparc_dir)
        if f.lower().endswith("_rotmod.dat") or f.lower().endswith("_rotmond.dat")
    )
    if not files:
        raise RuntimeError("No rotmod files found in " + sparc_dir)

    X_rows = []
    names = []
    gbar_list = []
    gobs_list = []
    gal_index_list = []

    # fixed radial grid in units of Rmax for NMF
    grid_frac = np.linspace(0.1, 1.0, n_bins)

    for fname in files:
        full = os.path.join(sparc_dir, fname)
        rv = read_one_rotmod(full)
        if rv is None:
            continue

        r, vobs, e_v, vbar = rv

        # --- NMF row: Vobs^2(r/Rmax) normalized ---
        Rmax = float(np.max(r))
        if not np.isfinite(Rmax) or Rmax <= 0:
            continue

        r_samp = grid_frac * Rmax
        # require galaxy to have data down to ~0.1 Rmax
        if np.min(r) > r_samp[0]:
            continue

        v_samp = np.interp(r_samp, r, vobs, left=np.nan, right=np.nan)
        if np.any(~np.isfinite(v_samp)):
            continue

        v2 = v_samp**2.0
        vmax = np.max(v2)
        if not np.isfinite(vmax) or vmax <= 0.0:
            continue

        row = v2 / vmax
        X_rows.append(row)
        names.append(os.path.splitext(fname)[0])
        gal_idx = len(names) - 1

        # --- RAR points for this galaxy ---
        vobs_si = vobs * 1.0e3   # m/s
        vbar_si = vbar * 1.0e3   # m/s
        r_si    = r * KPC_TO_M   # m

        g_obs = vobs_si**2.0 / r_si
        g_bar = vbar_si**2.0 / r_si

        m_rar = (
            np.isfinite(g_obs) & np.isfinite(g_bar) &
            (g_obs > 0.0) & (g_bar > 0.0)
        )
        if not np.any(m_rar):
            continue

        g_obs, g_bar = g_obs[m_rar], g_bar[m_rar]
        gobs_list.append(g_obs)
        gbar_list.append(g_bar)
        gal_index_list.append(np.full_like(g_obs, gal_idx, dtype=int))

    if not X_rows:
        raise RuntimeError("No usable galaxies found in " + sparc_dir)

    X = np.vstack(X_rows)
    names = np.array(names)
    g_obs_all = np.concatenate(gobs_list)
    g_bar_all = np.concatenate(gbar_list)
    gal_index_all = np.concatenate(gal_index_list)

    return X, names, g_bar_all, g_obs_all, gal_index_all, grid_frac


def rar_model(g_bar, g_dag):
    """
    McGaugh+2016 RAR fit:
      g_obs = g_bar / (1 - exp(-sqrt(g_bar / g_dag)))
    """
    x = np.sqrt(g_bar / g_dag)
    # avoid division by zero or exact 1 in denominator
    denom = 1.0 - np.exp(-x)
    denom = np.where(denom <= 0.0, np.nan, denom)
    return g_bar / denom


def fit_gdag(g_bar, g_obs):
    """
    Fit g_dag by minimizing chi^2 in log space.
    Returns (g_dag_best, g_dag_low, g_dag_high, chi2_min, N_pts).
    """
    m = np.isfinite(g_bar) & np.isfinite(g_obs) & (g_bar > 0.0) & (g_obs > 0.0)
    g_bar = g_bar[m]
    g_obs = g_obs[m]
    N = g_bar.size
    if N == 0:
        return np.nan, np.nan, np.nan, np.nan, 0

    log_gbar = np.log10(g_bar)
    log_gobs = np.log10(g_obs)

    def chi2_ln(log_gdag):
        g_dag = 10.0**log_gdag
        g_mod = rar_model(g_bar, g_dag)
        log_gmod = np.log10(g_mod)
        res = log_gobs - log_gmod
        return np.sum(res**2.0)

    # search log10 g_dag in [-12, -8]
    res = minimize_scalar(chi2_ln, bounds=(-12.0, -8.0), method="bounded")
    log_gdag_best = res.x
    chi2_min = res.fun

    # crude 1-sigma error band via Δχ^2 = 1 scan
    xs = np.linspace(log_gdag_best - 0.5, log_gdag_best + 0.5, 200)
    chi2_vals = np.array([chi2_ln(x) for x in xs])
    mask = chi2_vals <= chi2_min + 1.0
    if np.any(mask):
        low = xs[mask].min()
        high = xs[mask].max()
    else:
        low = log_gdag_best
        high = log_gdag_best

    g_dag_best = 10.0**log_gdag_best
    g_dag_low  = 10.0**low
    g_dag_high = 10.0**high
    return g_dag_best, g_dag_low, g_dag_high, chi2_min, N


def run_sparc_rar_nmf(sparc_dir, out_dir, n_components=3, n_bins=15):
    print(f"Building NMF matrix and RAR inputs from {sparc_dir} ...")
    X, names, g_bar_all, g_obs_all, gal_index_all, grid_frac = build_nmf_and_rar_inputs(
        sparc_dir, n_bins=n_bins
    )
    Ngal, Nfeat = X.shape
    print(f" -> N_galaxies used in NMF: {Ngal}, N_points_per_curve: {Nfeat}")
    print(f" -> Total RAR points: {g_bar_all.size}")

    # ----- NMF on rotation-curve shapes -----
    model = NMF(
        n_components=n_components,
        init="nndsvda",
        max_iter=5000,
        random_state=123,
    )
    W = model.fit_transform(X)   # Ngal x n_components
    H = model.components_        # n_components x n_bins

    # normalize mixture fractions per galaxy
    W_sum = np.sum(W, axis=1, keepdims=True)
    W_sum[W_sum == 0.0] = 1.0
    F = W / W_sum   # fractions

    print("\n=== NMF mixture fractions per galaxy ===")
    header = "galaxy_id".ljust(25) + "  " + "  ".join(
        [f"f{j+1}" for j in range(n_components)]
    )
    print(header)
    for name, fracs in zip(names, F):
        fr_str = "  ".join(f"{x:6.3f}" for x in fracs)
        print(f"{name:25s}  {fr_str}")

    print("\n=== Mixture statistics ===")
    for j in range(n_components):
        comp = F[:, j]
        print(
            f"Component {j+1}: mean={comp.mean():.3f}, std={comp.std():.3f}, "
            f"min={comp.min():.3f}, max={comp.max():.3f}, N(f>0.8)={np.sum(comp>0.8)}"
        )

    # ----- Global RAR fit -----
    print("\n=== Global RAR fit (all galaxies) ===")
    gdag_all, gdag_lo_all, gdag_hi_all, chi2_all, N_all = fit_gdag(g_bar_all, g_obs_all)
    print(
        f"g_dag(all) = {gdag_all:.3e} "
        f"[{gdag_lo_all:.3e}, {gdag_hi_all:.3e}]  (N={N_all}, chi2={chi2_all:.2f})"
    )

    log_resid_all = np.log10(g_obs_all) - np.log10(rar_model(g_bar_all, gdag_all))
    print(
        f"Residuals (all): mean={log_resid_all.mean():.3f} dex, "
        f"std={log_resid_all.std():.3f} dex"
    )

    # ----- Group galaxies by dominant component -----
    dom_comp = np.argmax(F, axis=1)      # 0..(n_components-1)
    dom_frac = np.max(F, axis=1)         # dominant fraction

    groups = {}
    for j in range(n_components):
        # "pure" group: dominated by component j
        mask = (dom_comp == j) & (dom_frac >= 0.6)
        groups[f"comp{j+1}_dom"] = np.where(mask)[0]
    # mixed group
    groups["mixed"] = np.where(dom_frac < 0.6)[0]

    print("\n=== RAR by NMF-based groups ===")
    group_results = {}  # name -> dict with gdag etc.

    for gname, gal_indices in groups.items():
        if gal_indices.size == 0:
            print(f"{gname}: no galaxies in this group.")
            continue

        # collect RAR points for these galaxies
        mask_points = np.isin(gal_index_all, gal_indices)
        if not np.any(mask_points):
            print(f"{gname}: no RAR points (unexpected).")
            continue

        g_bar_g = g_bar_all[mask_points]
        g_obs_g = g_obs_all[mask_points]

        gdag_g, gdag_lo_g, gdag_hi_g, chi2_g, N_g = fit_gdag(g_bar_g, g_obs_g)
        if N_g < 50:
            print(f"{gname}: only {N_g} points, skipping detailed stats.")
            continue

        log_resid_g = np.log10(g_obs_g) - np.log10(rar_model(g_bar_g, gdag_g))
        print(
            f"{gname}: N_gal={gal_indices.size}, N_pts={N_g}, "
            f"g_dag={gdag_g:.3e} [{gdag_lo_g:.3e}, {gdag_hi_g:.3e}], "
            f"resid mean={log_resid_g.mean():.3f} dex, std={log_resid_g.std():.3f} dex"
        )

        group_results[gname] = dict(
            gal_indices=gal_indices,
            N_pts=N_g,
            g_dag=gdag_g,
            g_dag_lo=gdag_lo_g,
            g_dag_hi=gdag_hi_g,
            resid_mean=log_resid_g.mean(),
            resid_std=log_resid_g.std(),
        )

    # ----- Heuristic discovery flag -----
    discovery = False
    best_pair = None

    # look for groups with non-overlapping 1-sigma intervals in log10 g_dag
    keys = [k for k, v in group_results.items() if v["N_pts"] >= 50]
    for i in range(len(keys)):
        for j in range(i+1, len(keys)):
            gi = group_results[keys[i]]
            gj = group_results[keys[j]]
            # check if intervals [lo,hi] do not overlap
            if (gi["g_dag_hi"] < gj["g_dag_lo"]) or (gj["g_dag_hi"] < gi["g_dag_lo"]):
                discovery = True
                best_pair = (keys[i], keys[j])
                break
        if discovery:
            break

    if discovery:
        print("\n*** RAR + NMF DISCOVERY CANDIDATE ***")
        print(
            "Groups with significantly different g_dag (non-overlapping 1-sigma "
            f"intervals): {best_pair[0]} vs {best_pair[1]}"
        )
        print("Saving a RAR plot colored by dominant component into the results folder.")
        os.makedirs(out_dir, exist_ok=True)

        # simple color map: comp1, comp2, comp3, mixed
        colors = {
            0: "C0",
            1: "C1",
            2: "C2",
            "mixed": "0.7",
        }
        fig, ax = plt.subplots()
        for idx_gal in range(Ngal):
            mask_pts = gal_index_all == idx_gal
            if not np.any(mask_pts):
                continue
            g_bar_g = g_bar_all[mask_pts]
            g_obs_g = g_obs_all[mask_pts]
            comp = dom_comp[idx_gal]
            frac = dom_frac[idx_gal]
            if frac < 0.6:
                c = colors["mixed"]
            else:
                c = colors.get(comp, "0.5")
            ax.scatter(
                np.log10(g_bar_g),
                np.log10(g_obs_g),
                s=5,
                alpha=0.4,
                c=c,
            )

        # overlay global RAR fit
        gbar_grid = np.logspace(-13, -8, 200)
        gobs_grid = rar_model(gbar_grid, gdag_all)
        ax.plot(
            np.log10(gbar_grid),
            np.log10(gobs_grid),
            "k-",
            linewidth=2.0,
            label="global RAR fit",
        )

        ax.set_xlabel(r"$\log_{10} g_{\mathrm{bar}}$ [m s$^{-2}$]")
        ax.set_ylabel(r"$\log_{10} g_{\mathrm{obs}}$ [m s$^{-2}$]")
        ax.legend()
        fig.tight_layout()
        out_png = os.path.join(out_dir, "sparc_rar_nmf_discovery.png")
        fig.savefig(out_png, dpi=200)
        plt.close(fig)
        print(f" -> Saved discovery plot: {out_png}")
    else:
        print("\n*** No RAR+NMF discovery flag by our heuristic criteria. ***")
        print("We still printed all mixture stats and group-by-group RAR fits to the console.")


def main():
    if len(sys.argv) != 3:
        print("Usage: sparc_rar_nmf_console.py SPARC_DIR OUTPUT_DIR")
        sys.exit(1)
    sparc_dir = sys.argv[1]
    out_dir   = sys.argv[2]
    run_sparc_rar_nmf(sparc_dir, out_dir, n_components=3, n_bins=15)


if __name__ == "__main__":
    main()
