﻿import os
import sys
import numpy as np
import pandas as pd
from sklearn.decomposition import NMF
import matplotlib.pyplot as plt

# --- basic constants: kpc/km/s -> m/s^2 ------------------------------------
KPC_IN_M  = 3.0856775814913673e19
KM2_IN_M2 = 1.0e6
ACC_FACTOR = KM2_IN_M2 / KPC_IN_M   # V[km/s]^2 / R[kpc] * ACC_FACTOR = m/s^2

# ---------------------------------------------------------------------------
# 1. Reading SPARC Rotmod files and building NMF + RAR inputs
# ---------------------------------------------------------------------------

def read_one_rotmod(path):
    """
    Read one SPARC 'XXXX_rotmod.dat' file.

    We assume columns:
      0: R[kpc]
      1: Vobs[km/s]
      2: eVobs[km/s]
      3: Vgas[km/s]   (if present)
      4: Vdisk[km/s]  (if present)
      5: Vbulge[km/s] (if present)

    Returns
    -------
    r_kpc, vobs, vgas, vdisk, vbulge
    or None if unusable.
    """
    try:
        df = pd.read_table(path, comment="#", header=None, delim_whitespace=True)
    except Exception as e:
        print(f"Failed to read {path}: {e}")
        return None

    if df.shape[1] < 3:
        return None

    r   = df.iloc[:, 0].to_numpy(dtype=float)
    vobs = df.iloc[:, 1].to_numpy(dtype=float)

    ncol = df.shape[1]
    vgas   = df.iloc[:, 3].to_numpy(dtype=float) if ncol > 3 else np.zeros_like(r)
    vdisk  = df.iloc[:, 4].to_numpy(dtype=float) if ncol > 4 else np.zeros_like(r)
    vbulge = df.iloc[:, 5].to_numpy(dtype=float) if ncol > 5 else np.zeros_like(r)

    m = np.isfinite(r) & np.isfinite(vobs) & (r > 0) & (vobs > 0)
    if not np.any(m):
        return None

    r, vobs, vgas, vdisk, vbulge = r[m], vobs[m], vgas[m], vdisk[m], vbulge[m]
    if r.size < 10:
        return None

    order = np.argsort(r)
    r      = r[order]
    vobs   = vobs[order]
    vgas   = vgas[order]
    vdisk  = vdisk[order]
    vbulge = vbulge[order]

    return r, vobs, vgas, vdisk, vbulge


def build_nmf_and_rar_inputs(sparc_dir, n_bins=15):
    """
    Build both:
      - NMF matrix X: N_gal x n_bins of normalized vobs^2(r/Rmax)
      - RAR dataframe: all (gbar, gobs) points across galaxies

    Returns
    -------
    X : (N_gal, n_bins) array
    names : (N_gal,) array of galaxy IDs (from filenames)
    rar_df : DataFrame with columns [galaxy_id, gbar, gobs]
    grid_frac : 1D array of r/Rmax sampling points
    """
    rows   = []
    names  = []
    rar_records = []

    files = sorted(
        f for f in os.listdir(sparc_dir)
        if f.lower().endswith("_rotmod.dat") or f.lower().endswith("_rotmond.dat")
    )

    for fname in files:
        full = os.path.join(sparc_dir, fname)
        rv = read_one_rotmod(full)
        if rv is None:
            continue
        r, vobs, vgas, vdisk, vbulge = rv
        if r.size < 10:
            continue

        Rmax = float(np.max(r))
        if not np.isfinite(Rmax) or Rmax <= 0:
            continue

        # --- build NMF row (normalized v^2 vs r/Rmax) -----------------------
        grid_frac = np.linspace(0.1, 1.0, n_bins)
        r_samp    = grid_frac * Rmax

        # require that we actually cover [0.1 Rmax, Rmax]
        if np.min(r) > r_samp[0] or np.max(r) < r_samp[-1]:
            continue

        vobs_samp = np.interp(r_samp, r, vobs)
        if not np.all(np.isfinite(vobs_samp)) or np.max(vobs_samp) <= 0:
            continue

        v2      = vobs_samp**2.0
        vmax2   = np.max(v2)
        if vmax2 <= 0 or not np.isfinite(vmax2):
            continue
        v2_norm = v2 / vmax2
        rows.append(v2_norm)
        gal_id = os.path.splitext(fname)[0]
        names.append(gal_id)

        # --- build RAR points for this galaxy -------------------------------
        gobs = vobs**2 * ACC_FACTOR / r
        vbar2 = vgas**2 + vdisk**2 + vbulge**2
        gbar = vbar2 * ACC_FACTOR / r

        m = np.isfinite(gobs) & np.isfinite(gbar) & (gobs > 0) & (gbar > 0)
        if not np.any(m):
            continue

        gobs = gobs[m]
        gbar = gbar[m]
        for go, gb in zip(gobs, gbar):
            rar_records.append(
                {"galaxy_id": gal_id, "gbar": gb, "gobs": go}
            )

    if len(rows) == 0:
        raise RuntimeError("No usable galaxies found in " + sparc_dir)

    X = np.vstack(rows)
    names = np.array(names)
    rar_df = pd.DataFrame(rar_records)
    rar_df["loggbar"] = np.log10(rar_df["gbar"])
    rar_df["loggobs"] = np.log10(rar_df["gobs"])

    return X, names, rar_df, grid_frac


# ---------------------------------------------------------------------------
# 2. RAR model and fitting (with Gaussian scatter)
# ---------------------------------------------------------------------------

def rar_model(gbar, g_dag):
    """
    McGaugh-style empirical RAR:
      g_obs = g_bar / (1 - exp(-sqrt(g_bar / g_dag)))
    """
    gbar = np.asarray(gbar, dtype=float)
    x = np.clip(gbar / g_dag, 1e-12, None)
    s = np.sqrt(x)
    denom = 1.0 - np.exp(-s)
    denom = np.clip(denom, 1e-6, None)
    return gbar / denom


def fit_rar_gdag(gbar, gobs, log_gdag_min=-12.5, log_gdag_max=-9.0, n_grid=220):
    """
    Fit g_dag by minimizing chi^2 in log10 space on a grid,
    and compute intrinsic scatter sigma_int assuming Gaussian residuals.

    Returns dict with:
      g_dag, g_dag_lo, g_dag_hi, chi2, N, resid_mean, resid_std, sigma_int
    """
    gbar = np.asarray(gbar, dtype=float)
    gobs = np.asarray(gobs, dtype=float)
    m = np.isfinite(gbar) & np.isfinite(gobs) & (gbar > 0) & (gobs > 0)
    if np.count_nonzero(m) < 10:
        return None

    gbar = gbar[m]
    gobs = gobs[m]
    loggbar = np.log10(gbar)
    loggobs = np.log10(gobs)

    log_grid = np.linspace(log_gdag_min, log_gdag_max, n_grid)
    chi2 = np.zeros_like(log_grid)

    for i, lg in enumerate(log_grid):
        g_dag = 10.0**lg
        gmod = rar_model(gbar, g_dag)
        loggmod = np.log10(gmod)
        res = loggobs - loggmod
        chi2[i] = np.sum(res**2)

    idx_best = int(np.argmin(chi2))
    logg_best = float(log_grid[idx_best])
    chi2_best = float(chi2[idx_best])

    # 1-sigma interval: Δχ² = 1
    mask_1s = chi2 <= chi2_best + 1.0
    if np.any(mask_1s):
        logg_lo = float(log_grid[mask_1s][0])
        logg_hi = float(log_grid[mask_1s][-1])
    else:
        logg_lo = logg_hi = logg_best

    g_dag     = 10.0**logg_best
    g_dag_lo  = 10.0**logg_lo
    g_dag_hi  = 10.0**logg_hi

    # Residuals at best fit and Gaussian intrinsic scatter
    gmod_best = rar_model(gbar, g_dag)
    loggmod_best = np.log10(gmod_best)
    res = loggobs - loggmod_best

    resid_mean = float(np.mean(res))
    resid_std  = float(np.std(res, ddof=1))
    # Gaussian MLE for intrinsic scatter (no measurement errors):
    sigma_int  = float(np.sqrt(np.mean(res**2)))

    return {
        "g_dag": g_dag,
        "g_dag_lo": g_dag_lo,
        "g_dag_hi": g_dag_hi,
        "chi2": chi2_best,
        "N": int(len(res)),
        "resid_mean": resid_mean,
        "resid_std": resid_std,
        "sigma_int": sigma_int,
    }


# ---------------------------------------------------------------------------
# 3. NMF, grouping, robustness scan
# ---------------------------------------------------------------------------

def run_nmf(X, n_components, seed):
    model = NMF(
        n_components=n_components,
        init="nndsvda",
        max_iter=4000,
        random_state=seed
    )
    W = model.fit_transform(X)
    H = model.components_
    W_sum = np.sum(W, axis=1, keepdims=True)
    W_sum[W_sum == 0.0] = 1.0
    F = W / W_sum
    return F, H


def assign_groups(names, F, threshold):
    """
    For each galaxy, find dominant component and classify as:

      compk_dom if max fraction >= threshold
      mixed     otherwise

    Returns
    -------
    gal_to_group : dict name -> group label
    dominant_idx : array of indices of dominant components
    max_frac     : array of dominant fractions
    """
    names = np.asarray(names)
    n_gal, n_comp = F.shape

    dominant = np.argmax(F, axis=1)
    max_frac = F[np.arange(n_gal), dominant]

    gal_to_group = {}
    for i, name in enumerate(names):
        if max_frac[i] >= threshold:
            g = f"comp{dominant[i] + 1}_dom"
        else:
            g = "mixed"
        gal_to_group[name] = g

    return gal_to_group, dominant, max_frac


# ---------------------------------------------------------------------------
# 4. Baseline plots and systematics helper
# ---------------------------------------------------------------------------

def make_baseline_plots(rar_df, gal_to_group, fit_global, out_dir):
    """
    Make paper-style plots for one baseline configuration:
      - RAR coloured by dominant component
      - Residual histograms per group
      - Boxplot of residuals per group
    """
    rar_df = rar_df.copy()
    rar_df["group"] = rar_df["galaxy_id"].map(gal_to_group).fillna("mixed")

    loggbar = np.log10(rar_df["gbar"].values)
    loggobs = np.log10(rar_df["gobs"].values)
    rar_df["loggbar"] = loggbar
    rar_df["loggobs"] = loggobs

    gmod = rar_model(rar_df["gbar"].values, fit_global["g_dag"])
    loggmod = np.log10(gmod)
    residual = loggobs - loggmod
    rar_df["residual"] = residual

    # --- RAR scatter with colours ------------------------------------------
    fig, ax = plt.subplots()
    ax.scatter(
        loggbar,
        loggobs,
        s=8,
        alpha=0.2,
        color="lightgray",
        label="_all"
    )

    group_colors = {
        "comp1_dom": "tab:blue",
        "comp2_dom": "tab:orange",
        "comp3_dom": "tab:green",
        "mixed":     "tab:red",
    }

    for g, color in group_colors.items():
        m = rar_df["group"] == g
        if not m.any():
            continue
        ax.scatter(
            rar_df.loc[m, "loggbar"],
            rar_df.loc[m, "loggobs"],
            s=12,
            alpha=0.8,
            color=color,
            label=g,
        )

    gbar_grid = np.logspace(loggbar.min(), loggbar.max(), 200)
    gobs_model = rar_model(gbar_grid, fit_global["g_dag"])
    ax.plot(
        np.log10(gbar_grid),
        np.log10(gobs_model),
        "k-",
        lw=2,
        label="global RAR fit",
    )

    ax.set_xlabel(r"$\log_{10} g_{\mathrm{bar}}\ [{\rm m\,s^{-2}}]$")
    ax.set_ylabel(r"$\log_{10} g_{\mathrm{obs}}\ [{\rm m\,s^{-2}}]$")
    ax.legend()
    fig.tight_layout()
    out_png = os.path.join(out_dir, "sparc_rar_nmf_robust_rar_baseline.png")
    fig.savefig(out_png, dpi=200)
    plt.close(fig)
    print(f"Saved baseline RAR plot to {out_png}")

    # --- residual histograms per group -------------------------------------
    groups = ["comp1_dom", "comp2_dom", "comp3_dom", "mixed"]
    fig, axes = plt.subplots(2, 2, figsize=(8, 6), sharex=True, sharey=True)
    axes = axes.ravel()

    for ax, g in zip(axes, groups):
        m = rar_df["group"] == g
        if m.any():
            ax.hist(rar_df.loc[m, "residual"], bins=30, alpha=0.8)
        ax.axvline(0.0, color="k", ls="--", lw=1)
        ax.set_title(g)

    axes[2].set_xlabel(r"$\Delta\log_{10} g$")
    axes[3].set_xlabel(r"$\Delta\log_{10} g$")
    axes[0].set_ylabel("N")
    axes[2].set_ylabel("N")

    fig.tight_layout()
    out_png = os.path.join(out_dir, "sparc_rar_nmf_baseline_residual_hist.png")
    fig.savefig(out_png, dpi=200)
    plt.close(fig)
    print(f"Saved baseline residual histograms to {out_png}")

    # --- boxplot of residuals ----------------------------------------------
    fig, ax = plt.subplots(figsize=(6, 4))
    data  = []
    labels = []
    for g in groups:
        m = rar_df["group"] == g
        if m.any():
            data.append(rar_df.loc[m, "residual"].values)
            labels.append(g)

    if data:
        ax.boxplot(data, labels=labels, showmeans=True)
        ax.axhline(0.0, color="k", ls="--", lw=1)
        ax.set_ylabel(r"$\Delta\log_{10} g$")
        fig.tight_layout()
        out_png = os.path.join(out_dir, "sparc_rar_nmf_baseline_residual_box.png")
        fig.savefig(out_png, dpi=200)
        plt.close(fig)
        print(f"Saved baseline residual boxplot to {out_png}")


# ---------------------------------------------------------------------------
# 5. Full robustness scan driver
# ---------------------------------------------------------------------------

def run_robust_scan(sparc_dir, out_dir):
    os.makedirs(out_dir, exist_ok=True)

    # NMF+RAR settings
    n_components_list = [2, 3, 4]
    n_bins_list       = [12, 15]
    seeds             = [7, 42, 123]
    thresholds        = [0.5, 0.6, 0.7]

    # "Baseline" config for paper plots
    baseline = {
        "n_components": 3,
        "n_bins": 15,
        "seed": 123,
        "threshold": 0.6,
    }

    summary_rows = []
    pair_rows    = []

    # cache NMF+RAR inputs per n_bins so we do not re-read files unnecessarily
    nmf_cache = {}
    for n_bins in n_bins_list:
        print(f"Building NMF/RAR inputs for n_bins={n_bins} ...")
        X, names, rar_df, grid_frac = build_nmf_and_rar_inputs(sparc_dir, n_bins=n_bins)
        print(f"  -> N_galaxies={X.shape[0]}, N_points_per_curve={X.shape[1]}, RAR points={len(rar_df)}")
        nmf_cache[n_bins] = (X, names, rar_df, grid_frac)

    baseline_rar_df   = None
    baseline_groups   = None
    baseline_mix_df   = None
    baseline_fit_glob = None

    print("\n=== ROBUSTNESS SCAN over NMF parameters and thresholds ===")

    for n_comp in n_components_list:
        for n_bins in n_bins_list:
            X, names, rar_df, grid_frac = nmf_cache[n_bins]

            for seed in seeds:
                print(f"\n-- Config: n_components={n_comp}, n_bins={n_bins}, seed={seed} --")
                F, H = run_nmf(X, n_comp, seed)

                # Mixture table for possible save
                mix_cols = [f"f{j+1}" for j in range(n_comp)]
                mixture_df = pd.DataFrame(F, columns=mix_cols)
                mixture_df.insert(0, "galaxy_id", names)

                # Global RAR fit (independent of threshold)
                fit_global = fit_rar_gdag(rar_df["gbar"].values, rar_df["gobs"].values)
                summary_rows.append(
                    dict(
                        n_components=n_comp,
                        n_bins=n_bins,
                        seed=seed,
                        threshold=np.nan,
                        group="all",
                        N_gal=len(set(rar_df["galaxy_id"])),
                        N_pts=len(rar_df),
                        **fit_global,
                    )
                )
                print(
                    "  Global g_dag = "
                    f"{fit_global['g_dag']:.3e} "
                    f"[{fit_global['g_dag_lo']:.3e}, {fit_global['g_dag_hi']:.3e}], "
                    f"sigma_int={fit_global['sigma_int']:.3f} dex"
                )

                # Threshold loop: build groups, fit per group, pairwise compare
                for thr in thresholds:
                    gal_to_group, dominant, max_frac = assign_groups(names, F, thr)

                    # Build RAR subsets per group
                    rar_groups = {}
                    for gal, grp in gal_to_group.items():
                        mask = rar_df["galaxy_id"] == gal
                        if not mask.any():
                            continue
                        if grp not in rar_groups:
                            rar_groups[grp] = []
                        rar_groups[grp].append(rar_df[mask])

                    for grp in list(rar_groups.keys()):
                        rar_groups[grp] = pd.concat(rar_groups[grp], ignore_index=True)

                    info_str = ", ".join(
                        f"{grp}:{len(set(df['galaxy_id']))} gal"
                        for grp, df in rar_groups.items()
                    )
                    print(f"  Threshold {thr:.2f}: {info_str}")

                    # Per-group RAR fits
                    group_results = {}
                    for grp, sub in rar_groups.items():
                        fit = fit_rar_gdag(sub["gbar"].values, sub["gobs"].values)
                        if fit is None:
                            continue
                        N_gal = len(set(sub["galaxy_id"]))
                        N_pts = len(sub)
                        row = dict(
                            n_components=n_comp,
                            n_bins=n_bins,
                            seed=seed,
                            threshold=thr,
                            group=grp,
                            N_gal=N_gal,
                            N_pts=N_pts,
                        )
                        row.update(fit)
                        summary_rows.append(row)
                        group_results[grp] = row
                        print(
                            f"    {grp}: N_gal={N_gal}, N_pts={N_pts}, "
                            f"g_dag={fit['g_dag']:.3e} "
                            f"[{fit['g_dag_lo']:.3e}, {fit['g_dag_hi']:.3e}], "
                            f"sigma_int={fit['sigma_int']:.3f} dex"
                        )

                    # Pairwise 1σ non-overlap checks
                    groups_sorted = sorted(group_results.keys())
                    for i in range(len(groups_sorted)):
                        for j in range(i + 1, len(groups_sorted)):
                            g1 = groups_sorted[i]
                            g2 = groups_sorted[j]
                            r1 = group_results[g1]
                            r2 = group_results[g2]
                            sep = (r1["g_dag_lo"] > r2["g_dag_hi"]) or (
                                r2["g_dag_lo"] > r1["g_dag_hi"]
                            )
                            pair_rows.append(
                                dict(
                                    n_components=n_comp,
                                    n_bins=n_bins,
                                    seed=seed,
                                    threshold=thr,
                                    group1=g1,
                                    group2=g2,
                                    separated_1sigma=sep,
                                )
                            )
                            if sep:
                                print(f"    >>> Non-overlapping 1σ g_dag: {g1} vs {g2}")

                    # Capture baseline config for plotting
                    if (
                        n_comp == baseline["n_components"]
                        and n_bins == baseline["n_bins"]
                        and seed == baseline["seed"]
                        and thr == baseline["threshold"]
                    ):
                        baseline_rar_df = rar_df.copy()
                        baseline_groups = {
                            name: gal_to_group[name] for name in names
                        }
                        mixture_df["dominant_comp"] = dominant
                        mixture_df["dominant_frac"] = max_frac
                        baseline_mix_df = mixture_df.copy()
                        baseline_fit_glob = fit_global

    # --- save summary tables ------------------------------------------------
    sum_df = pd.DataFrame(summary_rows)
    sum_csv = os.path.join(out_dir, "sparc_rar_nmf_robust_groups.csv")
    sum_df.to_csv(sum_csv, index=False)

    pairs_df = pd.DataFrame(pair_rows)
    pairs_csv = os.path.join(out_dir, "sparc_rar_nmf_robust_pairs.csv")
    pairs_df.to_csv(pairs_csv, index=False)

    print(f"\nSaved group-level summary to {sum_csv}")
    print(f"Saved pairwise separation summary to {pairs_csv}")

    # --- save baseline mixture table + list of comp3_dom galaxies ----------
    if baseline_mix_df is not None:
        mix_csv = os.path.join(out_dir, "sparc_rar_nmf_baseline_mixtures.csv")
        baseline_mix_df.to_csv(mix_csv, index=False)
        print(f"Saved baseline mixture fractions to {mix_csv}")

        # comp3_dom = component index 2 (0-based) with fraction >= threshold
        comp3 = baseline_mix_df[
            (baseline_mix_df["dominant_comp"] == 2)
            & (baseline_mix_df["dominant_frac"] >= baseline["threshold"])
        ]["galaxy_id"].tolist()
        txt_path = os.path.join(
            out_dir, "sparc_rar_nmf_baseline_comp3_galaxies.txt"
        )
        with open(txt_path, "w") as f:
            f.write("# Galaxies classified as comp3_dom in baseline config\n")
            for g in comp3:
                f.write(f"{g}\n")
        print(
            f"Saved list of baseline comp3_dom galaxies (for systematics checks) to {txt_path}"
        )
    else:
        print("WARNING: baseline configuration not found in scan; no comp3_dom list.")

    # --- baseline plots -----------------------------------------------------
    if baseline_rar_df is not None and baseline_groups is not None:
        make_baseline_plots(baseline_rar_df, baseline_groups, baseline_fit_glob, out_dir)
    else:
        print("WARNING: no baseline plots produced (baseline config missing).")


# ---------------------------------------------------------------------------
# 6. CLI entry point
# ---------------------------------------------------------------------------

def main():
    if len(sys.argv) != 3:
        print("Usage: sparc_rar_nmf_robust.py SPARC_DIR OUTPUT_DIR")
        sys.exit(1)
    sparc_dir = sys.argv[1]
    out_dir   = sys.argv[2]
    run_robust_scan(sparc_dir, out_dir)


if __name__ == "__main__":
    main()
